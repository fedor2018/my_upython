from pyb import ExtInt, Pin

def key_press(line):
    print(line)

# b4=Pin("B4", Pin.IN)
b4=ExtInt("B4", ExtInt.IRQ_RISING_FALLING, Pin.PULL_UP, key_press)

#print(b4.names(),b4.pin(), b4.value())
b4.swint()

