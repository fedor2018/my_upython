from pyb import ExtInt, Pin

def key_press(line):
    print(line)

x1=Pin("A0", Pin.OUT_OD)
x2=Pin("A1", Pin.OUT_OD)
x3=Pin("A2", Pin.OUT_OD)
x4=Pin("A3", Pin.OUT_OD)

y1=ExtInt("B5", ExtInt.IRQ_RISING_FALLING, Pin.PULL_NONE, key_press)
# y2=ExtInt("B4", ExtInt.IRQ_RISING_FALLING, Pin.PULL_UP, key_press)
y3=ExtInt("B3", ExtInt.IRQ_RISING_FALLING, Pin.PULL_NONE, key_press)
y4=ExtInt("A15", ExtInt.IRQ_RISING_FALLING, Pin.PULL_NONE, key_press)


while 1:
    pass
