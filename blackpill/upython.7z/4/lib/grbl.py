from pyb import UART
import time

class grbl:
    def __init__(self, port=1, baudrate=115200, debug=False):
        self.debug=debug
        self.uart=UART(port, baudrate)
        self.dbgmsg(self.uart)

    def disconnect(self):
        """ """
        self.uart.read() # flush rx buffer
        print("uart disconnect")
        self.uart.deinit()
        
        
    def __del__(self):
        self.disconnect()   

    def dbgmsg(self, m):
        """ print message if debug """
        if(self.debug):
            print(m)

    def send_read(self, c, t=1):
        """ send cmd and wait responce """
        self.uart.read() # flush rx buffer
        self.uart.write(c)
        self.dbgmsg("send: %s" % c)
        time.sleep_ms(t)
        s=self.uart.read()
        if(s is None):
            return ""
        else:
#             s2=bytes(x if x <127 else 0x20 for x in s) #.decode('UTF8').replace('$', '£')
#             print(s2)
            self.dbgmsg("read: %s" % s)
            return bytes(x if x <127 else 0x20 for x in s).decode("utf-8").strip("\r\n ")

    def is_connect(self):
        """ check connect """
        s=self.send_read(b"\r")
        if(s == 'ok'):
            print("connect")
            return True
        elif(s == ""):
            print("timeout")
        else:
            print("error: %s" % s)
        return False
    
    def req_parse(self, c, t=1):
        """ """
        s=self.send_read(c, t)
        print(s)
        if c.startswith('error:'):
            e = c.split(':')[1]
            print("error=%d" % e)
        elif c.startswith('[VER'):
            e = c.split(':')[1]
            print("ver=%d" % e)



