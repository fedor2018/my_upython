from grblcontrol import *

p=grblcontrol(debug=True, i2c_port=1)
p.connect()
# while 1:
p.upd_stat()

