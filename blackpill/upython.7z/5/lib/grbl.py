from pyb import UART
import time

class grbl:
    def __init__(self, port=1, baudrate=115200, debug=False):
        self.debug=debug
        self.uart=UART(port, baudrate)
        self.dbgmsg(self.uart)

    def disconnect(self):
        """ """
        while(self.uart.any()):
            self.uart.read() # flush rx buffer
        print("uart disconnect")
        self.uart.deinit()
        
        
    def __del__(self):
        self.disconnect()   

    def dbgmsg(self, m):
        """ print message if debug """
        if(self.debug):
            print(m)

    def send_read(self, c, t=1):
        """ send cmd and wait responce """
        t0=time.time_ns()
        while(self.uart.any()):
            self.uart.read() # flush rx buffer
        self.uart.write(c)
        self.dbgmsg("\nsend: %s" % c)
        time.sleep_ms(t)
        s=None
        while(self.uart.any()):
            time.sleep_ms(1)
            s=self.uart.read()
        print("delay: %dms" % ((time.time_ns()-t0)/1000000))
        if(s is None):
            return ""
        else:
#             s2=bytes(x if x <127 else 0x20 for x in s) #.decode('UTF8').replace('$', '£')
#             print(s2)
            self.dbgmsg("read: %s" % s)
            return bytes(x if x <127 else 0x20 for x in s).decode("utf-8").strip("\r\n ")

    def is_connect(self):
        """ check connect """
        s=self.send_read(b"\r")
        if(s == 'ok'):
            print("connect")
            return True
        elif(s == ""):
            print("timeout")
        else:
            print("error: %s" % s)
        return False
    
    def req_parse(self, c, t=1):
        """ """
        s=self.send_read(c, t)
        print(s)
        if c.startswith('error:'):
            e = c.split(':')[1]
            print("error=%d" % e)
        elif c.startswith('[VER'):
            e = c.split(':')[1]
            print("ver=%d" % e)

        elif s.startswith('<'):
            params = s.replace('<', '').replace('>', '').split('|')
            status = {}
            status['mode'] = params[0]

            for param in params[1:]:
                k, v = param.split(':')
                if ',' in v:
                    v = v.split(',')
                    for i, item in enumerate(v):
                        try:
                            v[i] = float(item)
                        except:
                            pass
                    status[k] = v
            print("status={}".format(status))
            return status


