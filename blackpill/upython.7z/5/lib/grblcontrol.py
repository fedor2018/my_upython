from grbl import *
from pyb import I2C, delay, millis
from pyb_i2c_lcd import I2cLcd
from lcd_v_minus import *
import time
"""
12345678901234567890
X=-xxx.xx F=xxx
Y=-xxx.xx
Z=-xxx.xx
Idle
"""
class grblcontrol:
    """ """
    def __init__(self, debug=False, uart_port=1, baudrate=115200, i2c_port=1, i2c_addr=0x27):
        self.debug=debug
        self.g=grbl(uart_port,baudrate,debug)
        startV()
        i2c = I2C(i2c_port, I2C.MASTER)
        if not i2c.is_ready(i2c_addr):
            print("i2c port=%d device 0x%x not found. Scan.." % (i2c_port, i2c_addr))
            i2c.scan()
            print ("end scan")
            raise "lcd not found"
        self.lcd = I2cLcd(i2c, i2c_addr, 4, 20)
        self.lcd.backlight_on()

    def __del__(self):
        self.lcd.backlight_off()

    def tstart(self):
        if(self.debug):
            self.t0=time.time_ns()

    def tstop(self):
        if(self.debug):
            print("delay: %dms" % ((time.time_ns()-self.t0)/1000000))

    def xy(self, x=0, y=0):
        self.lcd.move_to(x,y)
        
    def lcdprint(self, str=""):
        self.lcd.putstr(str)

    def connect(self):
        self.xy(0,5)
        self.lcdprint("grbl panel")
        if(self.g.is_connect()):
            self.xy(1,2)
            self.lcdprint("connected")
        else:
            self.lcdprint("error")
        time.sleep_ms(1000)
        self.lcd.clear()
        self.lcdstatic()

    def lcdstatic(self):
        self.xy()
        self.lcdprint("X=")
        self.xy(0,1)
        self.lcdprint("Y=")
        self.xy(0,2)
        self.lcdprint("Z=")
        
    def upd_stat(self):
        self.tstart()
        s=self.g.req_parse(b'?')
        for i in range(0,3):
            self.xy(2,i)
            self.lcdprint("{: 7.2f}".format(s['WPos'][i]))
        self.xy(0,3)
        self.lcdprint(s['mode'])
        self.tstop()
