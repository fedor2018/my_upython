# -*- coding: utf-8 -*-

"""Main module."""

# shortcut to Grbl interface
from .interface import Grbl


