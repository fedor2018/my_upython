# -*- coding: utf-8 -*-

"""Top-level package for Grbl Link."""

__author__ = """Darius Montez"""
__email__ = 'darius.montez@gmail.com'
__version__ = '0.1.4'
